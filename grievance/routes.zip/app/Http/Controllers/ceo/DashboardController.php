<?php

namespace App\Http\Controllers\ceo;

use App\Http\Controllers\Controller;
use App\Models\Complaint;
use App\Models\Inquiry;
use App\Models\InquiryTransactions;
use App\Models\Transition;
use App\User;
use Carbon\Carbon;
use App\Models\Resolution;
use App\Models\Department;

use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        try {
         $complaintid = Complaint::pluck('id')->all();
                        $resolveid = Resolution::pluck('complaint_id')->all();
          /////  $totalcomplaints = Transition::whereIn('complaintid',$complaintid)->get()->unique('complaintid')->count();
          $totalcomplaints = Complaint::get()->count();
              $departments = Department::with('users')->get();
                                       $resolvedcomplaintsonly = Transition::pluck('complaintid')->all();
            $resolvedcomplaints = Transition::where('is_resolved', 1)->whereIn('complaintid',$complaintid)->whereIn('complaintid',$resolveid)->get()->unique('complaintid')->count();
            $pendingcomplaints1 = Transition::where('is_resolved', 0)->whereIn('complaintid',$complaintid)->whereNotIn('complaintid',$resolveid)->get()->unique('complaintid')->count();
                 $pendingcomplaints = Complaint::whereNotIn('id',$resolvedcomplaintsonly)->whereNotIn('id',$resolveid)->get()->count();
                $pendingcomplaints=$pendingcomplaints + $pendingcomplaints1;
            $totalinquiries = Inquiry::count();
            $resolvedinquiries = InquiryTransactions::where('is_resolved', 1)->get()->unique('inquiryid')->count();
            $pendinginquiries = $totalinquiries - $resolvedinquiries;
            $highprioritycomplaints = Transition::where('tolevel', 3)->whereIn('complaintid',$complaintid)->where('is_resolved', 0)->count();
            $crossedtlcomplaints = Transition::where('is_resolved', 0)->whereIn('complaintid',$complaintid)->whereHas('complaint', function ($q) {
                $getdays = complaintlimit();
                $q->whereDate('created_at','<', Carbon::now()->subDays($getdays)->format('Y-m-d'));
                
            })->with('complaint')->orderBy('id', 'DESC')->get()->unique('complaintid')->count();
            return view('ceo.dashboard', compact('totalcomplaints', 'resolvedcomplaints', 'pendingcomplaints', 'totalinquiries', 'resolvedinquiries', 'pendinginquiries', 'highprioritycomplaints', 'crossedtlcomplaints'));
        } catch (\Throwable $th) {
            $this->customerr($th);
        }
    }

    public function complaint()
    {
        try {
            $data = Transition::query();
                     $complaintid = Complaint::pluck('id')->all();
                                         $resolveid = Resolution::pluck('complaint_id')->all();                                           $resolvedcomplaintsonly = Transition::pluck('complaintid')->all();
            if (request()->has('type')) {
                if (request()->get('type') == 'resolved') {
                 //$data = $data->where('is_resolved', 1);
                             $data = $data->orderBy('id', 'DESC')->whereIn('complaintid',$complaintid)->whereIn('complaintid',$resolveid)->get()->unique('complaintid');
                 $data6 = Complaint::whereNotIn('id',$resolvedcomplaintsonly)->whereIn('id',$resolveid)->get();
                  ////  $data = Resolution::whereIn('complaint_id',$complaintid)->whereIn('complaint_id',$resolvedcomplaintsonly)->get()->unique('complaint_id')->count();
                  /////  $data = Resolution::whereIn('complaint_id',$complaintid)->whereNotIn('complaint_id',$resolvedcomplaintsonly)->get()->unique('complaint_id')->count();
                }
                if (request()->get('type') == 'pending') {
                    $data = Transition::where('is_resolved', 0)->whereIn('complaintid',$complaintid)->whereNotIn('complaintid',$resolveid)->get()->unique('complaintid');
                 $data6 = Complaint::whereNotIn('id',$resolvedcomplaintsonly)->whereNotIn('id',$resolveid)->get();

                }
                if (request()->get('type') == 'crossedtl') {

                    $data = $data->where('is_resolved', 0)->whereIn('complaintid',$complaintid)->whereNotIn('complaintid',$resolveid)->whereHas('complaint', function ($q) {
                        $getdays = complaintlimit();
                        $q->whereDate('created_at','<', Carbon::now()->subDays($getdays)->format('Y-m-d'));
                        
                    })->with('complaint');
                                $data = $data->orderBy('id', 'DESC')->get()->unique('complaintid');
                }
            } 
            else
            {
            $data6 = Complaint::whereNotIn('id',$resolvedcomplaintsonly)->get();
          //$collection = collect($data2);
   // $merged     = $collection->merge($data1);
    //$data   = $merged->all();
            $data = $data->orderBy('id', 'DESC')->whereIn('complaintid',$complaintid)->get()->unique('complaintid');

            }
            if (request()->has('employee')) {
                $emp = request()->get('employee');
                $data = $data->where('touser', $emp);
            }
            if (request()->has('startdate') && request()->has('enddate')) {
                $from = strtotime(request()->startdate);
                $from = date("Y-m-d", $from);
                $to = strtotime(request()->enddate);
                $to = date("Y-m-d", $to);
                // dd($from);
                $resolvedcomplaints = $data->whereRaw("(updated_at >= ? AND updated_at <= ?)", [$from." 00:00:00", $to." 23:59:59"]);
            }

                        $users = User::all();

                                   return view('ceo.complaint', compact('data', 'users','data6'));
          
        } catch (\Throwable $th) {
            $this->customerr($th);
        }
    }

    public function inquiry()
    {
        try {
            if (request()->has('startdate') && request()->has('enddate')) {
                $from = strtotime(request()->startdate);
                $from = date("Y-m-d", $from);
                $to = strtotime(request()->enddate);
                $to = date("Y-m-d", $to);
                $resolvedinquiries = InquiryTransactions::where('is_resolved', 1)->whereRaw("(updated_at >= ? AND updated_at <= ?)", [$from . " 00:00:00", $to . " 23:59:59"])->get()->unique('inquiryid');
                // dd($resolvedinquiries);
                $resolvedinquiryids = InquiryTransactions::where('is_resolved', 1)->pluck('inquiryid')->toArray();
                $pendinginquiries = Inquiry::whereNotIn('id', $resolvedinquiryids)->whereRaw("(created_at >= ? AND created_at <= ?)", [$from . " 00:00:00", $to . " 23:59:59"])->get();
            } else if (request()->has('employee')) {
                $employee = request()->employee;
                $resolvedinquiries = InquiryTransactions::where('is_resolved', 1)->where('touser', $employee)->get();
                $resolvedinquiryids = InquiryTransactions::where('is_resolved', 1)->pluck('inquiryid')->toArray();
                $pendinginquirieids = Inquiry::whereNotIn('id', $resolvedinquiryids)->pluck('id')->toArray();
                $pendinginquiries = InquiryTransactions::whereIn('inquiryid', $pendinginquirieids)->where('is_resolved', 0)->where('touser', $employee)->get();
            } else {
                $resolvedinquiries = InquiryTransactions::where('is_resolved', 1)->get()->unique('inquiryid');
                $resolvedinquiryids = InquiryTransactions::where('is_resolved', 1)->pluck('inquiryid')->toArray();
                $pendinginquiries = Inquiry::whereNotIn('id', $resolvedinquiryids)->get();
            }
            $users = User::all();
            return view('ceo.inquiry', compact('resolvedinquiries', 'pendinginquiries', 'users'));
        } catch (\Throwable $th) {
            $this->customerr($th);
        }
    }

    public function trackcomplaintform()
    {
        try {
            if (request()->has('refno')) {
                $refno = request()->get('refno');
                $getcomplaintid = Complaint::where('uuid', $refno)->first();
                if ($getcomplaintid) {
                    $complaintid = $getcomplaintid->id;
                    $gettransitions = Transition::where('complaintid', $complaintid)->get();
                } else {
                    $gettransitions = [];
                }
                return view('ceo.trackcomplaintform', compact('gettransitions'));
            }
            if (request()->has('mobileno')) {
                $mobileno = request()->get('mobileno');
                $getcomplaints = Complaint::where('mobile', $mobileno)->get();
                return view('ceo.trackcomplaintform', compact('getcomplaints'));
            }
            return view('ceo.trackcomplaintform');
        } catch (\Throwable $th) {
            //throw $th;
        }
    }

    public function trackinquiryform()
    {
        try {
            if (request()->has('refno')) {
                $refno = request()->get('refno');
                $getinquiryid = Inquiry::where('uuid', $refno)->first();
                if ($getinquiryid) {
                    $inquiryid = $getinquiryid->id;
                    $gettransitions = InquiryTransactions::where('inquiryid', $inquiryid)->get();
                    // dd($gettransitions);
                } else {
                    $gettransitions = [];
                }
                return view('ceo.trackinquiryform', compact('gettransitions'));
            }
            if (request()->has('mobileno')) {
                $mobileno = request()->get('mobileno');
                $getinquires = Inquiry::where('contact', $mobileno)->get();
                return view('ceo.trackinquiryform', compact('getinquires'));
            }
            return view('ceo.trackinquiryform');
        } catch (\Throwable $th) {
            //throw $th;
        }
    }

    public function showprofile()
    {
        try {
            return view('ceo.showprofile');
        } catch (\Throwable $th) {
            //throw $th;
        }
    }

    public function changepassword()
    {
        try {
            return view('ceo.changepassword');
        } catch (\Throwable $th) {
            //throw $th;
        }
    }
}
