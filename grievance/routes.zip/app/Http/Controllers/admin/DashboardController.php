<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Action;
use App\Models\ActionTriggers;
use App\Models\Configuration;
use App\Models\Inquiry;
use App\Models\InquiryTransactions;
use App\Models\Levels;
use App\Models\Logo;
use App\Models\NotificationChannels;
use App\Models\Transition;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Models\Resolution;
use Illuminate\Support\Facades\Hash;
use App\Models\Department;
use App\Models\Complaint;
class DashboardController extends Controller
{
    public function index()
    {
        try {
            $totalemployee = User::where('role', '!=', 0)->count();
              $departments = Department::with('users')->get();
                        $complaintid = Complaint::pluck('id')->all();
           // $totalgivieance = Transition::get()->unique('complaintid')->whereIn('complaintid',$complaintid)->count();
                     $totalgivieance = Complaint::get()->count();
                      $resolveid = Resolution::pluck('complaint_id')->all();
                      $resolvedcomplaintsonly = Transition::pluck('complaintid')->all();
            $inquiry = Inquiry::count();
            $resolveid = Resolution::pluck('complaint_id')->all();
            $highprioritycomplaint = Transition::where(['tolevel' => 3, 'is_resolved' => 0])->whereIn('complaintid',$complaintid)->whereNotIn('complaintid',$resolveid)->get()->unique('complaintid')->count();
            $activecomplaint1 = Transition::where('is_resolved', 0)->whereIn('complaintid',$complaintid)->whereNotIn('complaintid',$resolveid)->get()->unique('complaintid')->count();
                 $activecomplaint = Complaint::whereNotIn('id',$resolvedcomplaintsonly)->whereNotIn('id',$resolveid)->get()->count();
                $activecomplaint=$activecomplaint + $activecomplaint1;

            //$activecomplaint = Transition::where('is_resolved', 0)->whereIn('complaintid',$complaintid)->get()->unique('complaintid')->count();
            //$resolvedcomplaint = Transition::where('is_resolved', 1)->whereIn('complaintid',$complaintid)->whereIn('complaintid',$resolveid)->get()->unique('complaintid')->count();
             $resolvedcomplaint = Resolution::whereIn('complaint_id',$complaintid)->whereIn('complaint_id',$resolvedcomplaintsonly)->get()->unique('complaint_id')->count();
             $resolvedcomplaint1 = Resolution::whereIn('complaint_id',$complaintid)->whereNotIn('complaint_id',$resolvedcomplaintsonly)->get()->unique('complaint_id')->count();
                             $resolvedcomplaint=$resolvedcomplaint + $resolvedcomplaint1;
            $crossedtlcomplaint = Transition::where('is_resolved', 0)->whereIn('complaintid',$complaintid)->whereNotIn('complaintid',$resolveid)->whereHas('complaint', function ($q) {
                $getdays = complaintlimit();
                $q->whereDate('created_at', '<', Carbon::now()->subDays($getdays)->format('Y-m-d'));

            })->with('complaint')->orderBy('id', 'DESC')->get()->unique('complaintid')->count();

            $compalintstats = json_encode([$highprioritycomplaint, $activecomplaint, $resolvedcomplaint, $crossedtlcomplaint]);

            $compalintstatsdata = json_encode(['High Priority' => $highprioritycomplaint, 'Active Complaint' => $activecomplaint, 'Resolved Complaint' => $resolvedcomplaint, 'Crossed Timeline' => $crossedtlcomplaint]);

            // $highpriorityinquiry=InquiryTransactions::where(['tolevel' => 3, 'is_resolved' => 0])->count();
            $activeinquiry = InquiryTransactions::where('is_resolved', 0)->get()->unique('inquiryid')->count();
            $resolvedinquiry = InquiryTransactions::where('is_resolved', 1)->get()->unique('inquiryid')->count();

            $inquirystats = json_encode([$activeinquiry, $resolvedinquiry]);
            $inquirystatsdata = json_encode(['Active Inquiry' => $activeinquiry, 'Resolved Inquiry' => $resolvedinquiry]);
            return view('admin.dashboard', compact('totalemployee', 'totalgivieance', 'compalintstats', 'inquirystats', 'inquiry', 'compalintstatsdata', 'inquirystatsdata'));
        } catch (\Throwable $th) {
            $this->customerr($th);
        }
    }

    public function profile()
    {
        try {
            return view('admin.profile');
        } catch (\Throwable $th) {
            $this->customerr($th);
        }
    }

    public function updateprofile(Request $request)
    {
        try {
            $data = $request->except('_token', 'file');
            if (request()->has('file')) {
                $foldername = 'userprofile';
                $image = $request->file('file')->store($foldername, 'public');
                $data['profileimage'] = $image;
            }

            $update = User::findorFail(auth()->user()->id)->update($data);
            return redirect()->back()->with('success', 'Updated successfully!');

        } catch (\Throwable $th) {
            $this->customerr($th);
            return redirect()->back()->with('error', 'Something went wrong . Please try again!');

        }
    }

    public function notificationmethods()
    {
        try {
            $data = NotificationChannels::all();
            return view('admin.notificationmethod', compact('data'));
        } catch (\Throwable $th) {
            $this->customerr($th);
        }
    }

    public function levels()
    {
        try {
            $data = Levels::all();
            $configuration = Configuration::all();
            return view('admin.levels', compact('data', 'configuration'));
        } catch (\Throwable $th) {
            $this->customerr($th);
        }
    }

    public function configurationupdate(Request $request)
    {
        try {
            $update = Configuration::where(['from' => $request->from, 'to' => $request->to])->update(['days' => $request->days]);
            return redirect()->back();
        } catch (\Throwable $th) {
            $this->customerr($th);
        }
    }
    public function changepassword()
    {
        try {
            return view('admin.changepassword');
        } catch (\Throwable $th) {
            //throw $th;
        }
    }

    public function userchangepassword(Request $request)
    {
        try {
            $id = auth()->user()->id;
            $getuser = User::find($id);
            if (Hash::check($request->oldpass, $getuser->password)) {
                $password = Hash::make($request->conpass);
                $q = User::where('id', $id)->update(['password' => $password]);
                return redirect()->back()->with('msg', 'Password changed successfully.');
            } else {
                return redirect()->back()->with('message', 'Wrong old password. Please try again.');
            }
        } catch (\Throwable $th) {
            //throw $th;
        }
    }

    public function configurationactions()
    {
        try {
            $data = Action::all();
            return view('admin.configuration', compact('data'));
        } catch (\Throwable $th) {
            $this->customerr($th);
        }
    }

    public function configureactionshandel(Request $request)
    {
        try {
            $email = $request->has('email') ? 1 : 0;
            $sms = $request->has('sms') ? 1 : 0;
            $whatsapp = $request->has('whatsapp') ? 1 : 0;
            ActionTriggers::where(['action_id' => $request->actionid, 'role' => $request->role])->update(['is_email' => $email, 'is_sms' => $sms, 'is_whatsapp' => $whatsapp]);
            return redirect()->back();
        } catch (\Throwable $th) {
            $this->customerr($th);

        }
    }

    public function uploadlogoview()
    {
        return view('admin.uploadlogo');
    }

    public function uploadlogo(Request $request)
    {
        $validated = $request->validate([
            'file' => 'required|image|mimes:jpeg,png,jpg|max:2048|dimensions:max_width=100,max_height=62',
        ]);
        if ($request->has('file')) {
            $foldername = 'Logo';
            $image = $request->file('file')->store($foldername, 'public');
            $check = Logo::count();
            if ($check) {
                Logo::where('id', 1)->update(['logo' => $image]);
            } else {
                Logo::create(['logo' => $image]);
            }
            return redirect()->back()->with('msg', 'Logo uploaded successfully');
        }
    }
    public function totalcomplaints()
    {
        $data = Transition::query();
        $complaintid = Complaint::pluck('id')->all();
         $resolveid = Resolution::pluck('complaint_id')->all();                                         
        $resolvedcomplaintsonly = Transition::pluck('complaintid')->all();
       // $data = $data->orderBy('id', 'DESC')->get()->unique('complaintid');
      $data = $data->orderBy('id', 'DESC')->whereIn('complaintid',$complaintid)->get()->unique('complaintid');
      $data6 = Complaint::whereNotIn('id',$resolvedcomplaintsonly)->get();
            $users = User::all();
            return view('admin.total_complaints', compact('data', 'users','data6'));
    }
    public function totalinq()
    {
        $resolvedinquiries = InquiryTransactions::where('is_resolved', 1)->get()->unique('inquiryid');
        $resolvedinquiryids = InquiryTransactions::where('is_resolved', 1)->pluck('inquiryid')->toArray();
        $pendinginquiries = Inquiry::whereNotIn('id', $resolvedinquiryids)->get();
            $users = User::all();
            return view('admin.total_inq', compact('resolvedinquiries', 'pendinginquiries', 'users'));
    }
}
