<?php

namespace App\Exports;

use App\OtherFee;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Carbon\Carbon;
class OtherExport implements FromCollection, WithHeadings
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public $data;

    public function __construct($data)
    {
         $this->data=$data;
       
    }
    public function collection()
    {
          $i=1;
         foreach($this->data as $one)
         {
               
                $one->uuid=$one->uuid;
                $one->customername=$one->customername;
                $one->mobile=$one->mobile;
                $one->details=$one->details;
                $one->complainttype=$one->complainttype;
                $one->complaintsource=$one->complaintsource;
                $one->created_at=$one->created_at;
                $one->title=$one->title;
                $one->is_resolved=$one->is_resolved;
                $one->email=$one->email;
                $i++;
         }
        
         return $this->data;

         
    }

    public function headings(): array
    {
        return ["uuid","customername","mobile", "details", "complainttype",'complaintsource','created_at','title',"is_resolved","email"];
    }
}
