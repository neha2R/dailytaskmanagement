<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class NotificationChannels extends Model
{
    //
}
