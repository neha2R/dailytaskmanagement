@extends('juniorlevel.layout.jlevelapp')
@section('content')
    @component('components.common.changepassword')
        
    @endcomponent
@endsection