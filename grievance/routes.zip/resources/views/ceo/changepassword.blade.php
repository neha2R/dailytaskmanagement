@extends('ceo.layout.app')
@section('content')
    @component('components.common.changepassword')
        
    @endcomponent
@endsection