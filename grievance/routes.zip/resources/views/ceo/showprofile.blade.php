@extends('ceo.layout.app')
@section('content')
    @component('components.common.updateprofile')
        
    @endcomponent
@endsection