@extends('admin.layout.adminapp')
@section('content')
    @component('components.common.updateprofile')
        
    @endcomponent
@endsection
