@extends('admin.layout.adminapp')
@section('content')
    @component('components.common.changepassword')
        
    @endcomponent
@endsection