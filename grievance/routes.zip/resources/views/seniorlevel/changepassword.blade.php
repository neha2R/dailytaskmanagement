@extends('seniorlevel.layout.slevelapp')
@section('content')
    @component('components.common.changepassword')
        
    @endcomponent
@endsection