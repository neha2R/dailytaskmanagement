<!DOCTYPE html>
<html>
<head>
    <title>Report</title>
</head>
<body>
    <h1>Dsily Report</h1>
    <p>This is monthly report mail Scheduling at 10 am in the mornign daily</p>

    <p>Thank you</p>
</body>
</html>