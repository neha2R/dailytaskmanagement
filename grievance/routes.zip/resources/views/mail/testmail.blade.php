<h1>Hi, </h1>
  @php
                            $url = URL::to('/auth/login');
                           
                        @endphp
<td> <a href="{{$url}}" target="_blank">Follow the Grievance</a> </td>

<p>This is for testing <strong>Don't</strong>  Worry Be Happy.</p>